import { useMemo } from 'react'

/* ─── Reactbits-style fire ember particles ───────────────────────────── */
const EMBER_COLORS = [
  '#ff4500', '#ff6200', '#ff8c00', '#ffa500',
  '#ffbf00', '#e63900', '#ff5500',
]

function FireBackground() {
  const embers = useMemo(() => (
    Array.from({ length: 55 }, (_, i) => ({
      id: i,
      left:     Math.random() * 100,
      delay:    Math.random() * 12,
      duration: 5 + Math.random() * 8,
      size:     1.5 + Math.random() * 3.5,
      drift:    (Math.random() - 0.5) * 80,
      opacity:  0.35 + Math.random() * 0.55,
      color:    EMBER_COLORS[Math.floor(Math.random() * EMBER_COLORS.length)],
    }))
  ), [])

  /* ambient glow orbs */
  const orbs = useMemo(() => ([
    { id: 0, x: 15,  y: 80, r: 340, color: 'rgba(232,80,10,0.055)', dur: 9 },
    { id: 1, x: 80,  y: 70, r: 280, color: 'rgba(255,100,0,0.04)',  dur: 13 },
    { id: 2, x: 50,  y: 90, r: 500, color: 'rgba(200,50,0,0.035)',  dur: 17 },
    { id: 3, x: 30,  y: 95, r: 220, color: 'rgba(255,140,0,0.04)',  dur: 7  },
  ]), [])

  return (
    <div className="fire-bg" aria-hidden="true">
      {/* ambient orbs */}
      {orbs.map(orb => (
        <div
          key={orb.id}
          className="fire-bg__orb"
          style={{
            left:     `${orb.x}%`,
            top:      `${orb.y}%`,
            width:    `${orb.r}px`,
            height:   `${orb.r}px`,
            background: `radial-gradient(circle, ${orb.color} 0%, transparent 70%)`,
            animationDuration: `${orb.dur}s`,
            animationDelay:    `${orb.id * 1.8}s`,
          }}
        />
      ))}

      {/* ember particles */}
      {embers.map(e => (
        <span
          key={e.id}
          className="fire-bg__ember"
          style={{
            left:              `${e.left}%`,
            width:             `${e.size}px`,
            height:            `${e.size}px`,
            background:        e.color,
            boxShadow:         `0 0 ${e.size * 3}px ${e.size}px ${e.color}`,
            animationDuration: `${e.duration}s`,
            animationDelay:    `${e.delay}s`,
            '--drift':         `${e.drift}px`,
            '--max-opacity':   e.opacity,
          }}
        />
      ))}
    </div>
  )
}

export default FireBackground
