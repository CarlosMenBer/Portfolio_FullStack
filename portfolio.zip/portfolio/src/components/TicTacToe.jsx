import { useState, useCallback } from 'react'
import { Users, Bot, RotateCcw } from 'lucide-react'

const WINNING_COMBOS = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
]

function checkWinner(board) {
  for (const [a, b, c] of WINNING_COMBOS) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a], line: [a, b, c] }
    }
  }
  return null
}

function bestMove(board) {
  const empty = board.map((v, i) => v === null ? i : null).filter(v => v !== null)
  for (const idx of empty) {
    const b = [...board]; b[idx] = 'O'
    if (checkWinner(b)) return idx
  }
  for (const idx of empty) {
    const b = [...board]; b[idx] = 'X'
    if (checkWinner(b)) return idx
  }
  if (board[4] === null) return 4
  const corners = [0, 2, 6, 8].filter(i => board[i] === null)
  if (corners.length) return corners[Math.floor(Math.random() * corners.length)]
  return empty[Math.floor(Math.random() * empty.length)]
}

function TicTacToe() {
  const [board, setBoard] = useState(Array(9).fill(null))
  const [xIsNext, setXIsNext] = useState(true)
  const [vsAI, setVsAI] = useState(false)
  const [scores, setScores] = useState({ X: 0, O: 0, draw: 0 })
  const [gameOver, setGameOver] = useState(false)

  const result = checkWinner(board)
  const isDraw = !result && board.every(Boolean)

  const handleClick = useCallback((idx) => {
    if (board[idx] || gameOver) return
    const newBoard = [...board]
    newBoard[idx] = xIsNext ? 'X' : 'O'

    const res = checkWinner(newBoard)
    if (res) {
      setBoard(newBoard)
      setScores(s => ({ ...s, [res.winner]: s[res.winner] + 1 }))
      setGameOver(true)
      return
    }
    if (newBoard.every(Boolean)) {
      setBoard(newBoard)
      setScores(s => ({ ...s, draw: s.draw + 1 }))
      setGameOver(true)
      return
    }

    if (vsAI && xIsNext) {
      const aiIdx = bestMove(newBoard)
      newBoard[aiIdx] = 'O'
      const res2 = checkWinner(newBoard)
      if (res2) {
        setBoard(newBoard)
        setScores(s => ({ ...s, [res2.winner]: s[res2.winner] + 1 }))
        setGameOver(true)
        return
      }
      if (newBoard.every(Boolean)) {
        setBoard(newBoard)
        setScores(s => ({ ...s, draw: s.draw + 1 }))
        setGameOver(true)
        return
      }
      setBoard(newBoard)
    } else {
      setBoard(newBoard)
      setXIsNext(!xIsNext)
    }
  }, [board, xIsNext, vsAI, gameOver])

  const reset = () => {
    setBoard(Array(9).fill(null))
    setXIsNext(true)
    setGameOver(false)
  }

  const switchMode = (ai) => {
    setVsAI(ai)
    setBoard(Array(9).fill(null))
    setXIsNext(true)
    setGameOver(false)
    setScores({ X: 0, O: 0, draw: 0 })
  }

  const getStatus = () => {
    if (result) return vsAI && result.winner === 'O' ? 'La IA gana esta ronda' : `Gana ${result.winner}`
    if (isDraw) return 'Empate'
    if (vsAI) return xIsNext ? 'Tu turno' : 'Turno de la IA'
    return `Turno de ${xIsNext ? 'X' : 'O'}`
  }

  return (
    <section className="tictactoe">
      <div className="section-header">
        <h2 className="section-title">Tic Tac <span className="highlight">Toe</span></h2>
        <p className="section-subtitle">El clásico de siempre, directamente en el portfolio</p>
      </div>

      <div className="ttt__container">
        <div className="ttt__mode">
          <button
            className={`btn ${!vsAI ? 'btn--primary' : 'btn--outline'}`}
            onClick={() => switchMode(false)}
          >
            <Users size={15} />
            2 Jugadores
          </button>
          <button
            className={`btn ${vsAI ? 'btn--primary' : 'btn--outline'}`}
            onClick={() => switchMode(true)}
          >
            <Bot size={15} />
            vs IA
          </button>
        </div>

        <div className="ttt__scores">
          <div className="ttt__score ttt__score--x">
            <span>{vsAI ? 'Tú (X)' : 'Jugador X'}</span>
            <strong>{scores.X}</strong>
          </div>
          <div className="ttt__score ttt__score--draw">
            <span>Empate</span>
            <strong>{scores.draw}</strong>
          </div>
          <div className="ttt__score ttt__score--o">
            <span>{vsAI ? 'IA (O)' : 'Jugador O'}</span>
            <strong>{scores.O}</strong>
          </div>
        </div>

        <p className={`ttt__status ${(result || isDraw) ? 'ttt__status--end' : ''}`}>
          {getStatus()}
        </p>

        <div className="ttt__board-wrap">
          <div className="ttt__board">
            {board.map((cell, i) => (
              <button
                key={i}
                className={[
                  'ttt__cell',
                  cell ? `ttt__cell--${cell.toLowerCase()}` : '',
                  result?.line?.includes(i) ? 'ttt__cell--win' : '',
                ].filter(Boolean).join(' ')}
                onClick={() => handleClick(i)}
                disabled={!!cell || gameOver}
              >
                {cell}
              </button>
            ))}
          </div>
        </div>

        <div className="ttt__actions">
          <button
            className={`btn ${(result || isDraw) ? 'btn--primary' : 'btn--outline'}`}
            onClick={reset}
          >
            <RotateCcw size={14} />
            {(result || isDraw) ? 'Jugar de nuevo' : 'Reiniciar'}
          </button>
        </div>
      </div>
    </section>
  )
}

export default TicTacToe
