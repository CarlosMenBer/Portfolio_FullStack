import { Download, ArrowRight, Code2 } from 'lucide-react'

const skills = [
  'React', 'JavaScript', 'Node.js', 'Python',
  'HTML & CSS', 'Git', 'SQL', 'TypeScript',
]

function Profile({ navigate }) {
  return (
    <section className="profile">
      <div className="profile__container">
        <div className="profile__text">
          <div className="profile__label">
            <Code2 size={12} />
            Desarrollador Full Stack
          </div>
          <h1 className="profile__name">Tu Nombre</h1>
          <h2 className="profile__role">
            Creando experiencias <span className="highlight">digitales</span>
          </h2>
          <p className="profile__bio">
            Apasionado por construir interfaces modernas y funcionales.
            Me especializo en aplicaciones web con tecnologías actuales,
            siempre buscando la solución más elegante para cada reto.
          </p>

          <div className="profile__skills">
            {skills.map(skill => (
              <span key={skill} className="skill-tag">{skill}</span>
            ))}
          </div>

          <div className="profile__buttons">
            <a href="/cv.pdf" download className="btn btn--primary">
              <Download size={16} />
              Descargar CV
            </a>
            <button className="btn btn--outline" onClick={() => navigate('contact')}>
              Contactarme
              <ArrowRight size={15} />
            </button>
          </div>
        </div>

        <div className="profile__avatar-wrapper">
          <div className="profile__avatar-ring" />
          <div className="profile__avatar-ring profile__avatar-ring--2" />
          <div className="profile__avatar">
            <div className="profile__avatar-inner">
              {/* Reemplaza con tu foto: <img src="/foto.jpg" alt="Tu nombre" /> */}
              <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <circle cx="50" cy="38" r="22" fill="#c47b3a" opacity="0.85" />
                <ellipse cx="50" cy="85" rx="32" ry="20" fill="#8b5e3c" opacity="0.8" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Profile
