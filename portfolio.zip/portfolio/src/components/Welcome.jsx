import { useRef } from 'react'
import { ClipboardList, User, Mail, Grid3x3, Camera } from 'lucide-react'

/* ─── ShinyText — reactbits.dev ─────────────────────────────────────── */
function ShinyText({ children, className = '' }) {
  return <span className={`shiny-text ${className}`}>{children}</span>
}

/* ─── LetterFade — reactbits.dev ────────────────────────────────────── */
function LetterFade({ text, className = '' }) {
  return (
    <span className={`letter-fade ${className}`} aria-label={text}>
      {text.split('').map((ch, i) => (
        <span
          key={i}
          className="letter-fade__char"
          style={{ animationDelay: `${i * 0.06}s` }}
        >
          {ch === ' ' ? '\u00A0' : ch}
        </span>
      ))}
    </span>
  )
}

/* ─── TiltBubble — 3D tilt on hover ────────────────────────────────── */
function TiltBubble({ mod, onClick }) {
  const ref = useRef(null)
  const { Icon } = mod

  const onMove = (e) => {
    const rect = ref.current.getBoundingClientRect()
    const x = (e.clientX - rect.left) / rect.width  - 0.5
    const y = (e.clientY - rect.top)  / rect.height - 0.5
    ref.current.style.transform =
      `perspective(600px) rotateX(${-y * 18}deg) rotateY(${x * 18}deg) scale(1.08)`
  }
  const onLeave = () => {
    ref.current.style.transform = ''
  }

  return (
    <button
      ref={ref}
      className="bubble"
      onClick={onClick}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      style={{
        '--bubble-color': mod.color,
        '--bubble-glow':  mod.glow,
        animationDelay:   mod.delay,
      }}
    >
      {/* inner glow ring */}
      <span className="bubble__ring" />

      <span className="bubble__icon-wrapper">
        <Icon size={32} strokeWidth={1.5} />
      </span>
      <span className="bubble__title">{mod.title}</span>
      <span className="bubble__subtitle">{mod.subtitle}</span>
    </button>
  )
}

/* ─── Module definitions ────────────────────────────────────────────── */
const MODULES = [
  {
    id: 'forum',
    Icon: ClipboardList,
    title: 'Tablón',
    subtitle: 'Deja tu mensaje',
    color: '#e8650a',
    glow: 'rgba(232,101,10,0.55)',
    delay: '0s',
  },
  {
    id: 'profile',
    Icon: User,
    title: 'Perfil',
    subtitle: 'Sobre mí & CV',
    color: '#d4541a',
    glow: 'rgba(212,84,26,0.5)',
    delay: '0.4s',
  },
  {
    id: 'contact',
    Icon: Mail,
    title: 'Contacto',
    subtitle: 'Escríbeme',
    color: '#c4830a',
    glow: 'rgba(196,131,10,0.5)',
    delay: '0.8s',
  },
  {
    id: 'tictactoe',
    Icon: Grid3x3,
    title: 'Tic Tac Toe',
    subtitle: 'Juega conmigo',
    color: '#b05020',
    glow: 'rgba(176,80,32,0.5)',
    delay: '1.2s',
  },
]

/* ─── Welcome ────────────────────────────────────────────────────────── */
function Welcome({ navigate }) {
  return (
    <section className="welcome">
      {/* ── Hero ── */}
      <div className="welcome__hero">
        <div className="welcome__photo-ring">
          <div className="welcome__photo">
            {/*
              Para usar tu foto real:
              <img src="/foto.jpg" alt="Tu nombre" className="welcome__photo-img" />
              Pon el archivo en la carpeta public/
            */}
            <Camera size={36} strokeWidth={1.2} className="welcome__photo-placeholder" />
          </div>
          <div className="welcome__photo-glow" />
        </div>

        <div className="welcome__tag">Portfolio</div>

        <h1 className="welcome__name">
          <LetterFade text="Tu Nombre" />
        </h1>

        <p className="welcome__role">
          <ShinyText>Desarrollador Full Stack</ShinyText>
        </p>

        <p className="welcome__tagline">
          Elige un módulo para explorar
        </p>

        {/* decorative separator */}
        <div className="welcome__sep">
          <span />
          <span className="welcome__sep-dot" />
          <span />
        </div>
      </div>

      {/* ── Bubbles ── */}
      <div className="welcome__bubbles">
        {MODULES.map(mod => (
          <TiltBubble
            key={mod.id}
            mod={mod}
            onClick={() => navigate(mod.id)}
          />
        ))}
      </div>
    </section>
  )
}

export default Welcome
