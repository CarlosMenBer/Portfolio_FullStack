import { useState, useEffect } from 'react'
import { Send, User, MessageSquarePlus, Pencil } from 'lucide-react'

function ForumPost({ note }) {
  const initial = note.author.charAt(0).toUpperCase()
  return (
    <div className="forum-post" style={{ '--post-color': note.color }}>
      <div className="forum-post__avatar" style={{ background: note.color }}>
        {initial}
      </div>
      <div className="forum-post__body">
        <div className="forum-post__header">
          <span className="forum-post__author">{note.author}</span>
          <span className="forum-post__date">{note.date}</span>
        </div>
        <p className="forum-post__message">{note.message}</p>
      </div>
    </div>
  )
}

function Forum() {
  const [notes, setNotes] = useState([])
  const [author, setAuthor] = useState('')
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  useEffect(() => {
    fetch('/api/notes')
      .then(res => res.json())
      .then(data => { setNotes(data); setLoading(false) })
      .catch(() => { setError('No se pudieron cargar los mensajes.'); setLoading(false) })
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSuccess(false)
    if (!author.trim() || !message.trim()) {
      setError('Por favor completa todos los campos.')
      return
    }
    setSubmitting(true)
    try {
      const res = await fetch('/api/notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ author, message }),
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error || 'Error al publicar el mensaje.')
      } else {
        setNotes(prev => [data, ...prev])
        setAuthor('')
        setMessage('')
        setSuccess(true)
        setTimeout(() => setSuccess(false), 3000)
      }
    } catch {
      setError('No se pudo conectar con el servidor.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <section className="forum">
      <div className="section-header">
        <h2 className="section-title">Tablón de <span className="highlight">Anuncios</span></h2>
        <p className="section-subtitle">
          Deja un mensaje, una opinión o simplemente saluda.
        </p>
      </div>

      <div className="forum__layout">
        <div className="forum__form-wrapper">
          <p className="forum__form-title">
            <Pencil size={13} />
            Nuevo mensaje
          </p>
          <form className="forum__form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="forum-author">
                <User size={12} />
                Tu nombre
              </label>
              <input
                id="forum-author"
                type="text"
                placeholder="¿Cómo te llamas?"
                value={author}
                onChange={e => setAuthor(e.target.value)}
                maxLength={50}
                disabled={submitting}
              />
            </div>
            <div className="form-group">
              <label htmlFor="forum-message">
                <MessageSquarePlus size={12} />
                Mensaje
              </label>
              <textarea
                id="forum-message"
                placeholder="Escribe tu mensaje aquí..."
                value={message}
                onChange={e => setMessage(e.target.value)}
                maxLength={300}
                rows={4}
                disabled={submitting}
              />
              <span className="char-count">{message.length}/300</span>
            </div>

            {error && <p className="form-error">{error}</p>}
            {success && <p className="form-success">Mensaje publicado correctamente</p>}

            <button type="submit" className="btn btn--primary btn--full" disabled={submitting}>
              <Send size={15} />
              {submitting ? 'Publicando...' : 'Publicar'}
            </button>
          </form>
        </div>

        <div className="forum__feed">
          {loading && (
            <div className="forum__loading">
              <div className="spinner" />
              <p>Cargando mensajes...</p>
            </div>
          )}
          {!loading && notes.length === 0 && (
            <p className="forum__empty">Sé el primero en dejar un mensaje</p>
          )}
          {notes.map(note => (
            <ForumPost key={note.id} note={note} />
          ))}
        </div>
      </div>
    </section>
  )
}

export default Forum
