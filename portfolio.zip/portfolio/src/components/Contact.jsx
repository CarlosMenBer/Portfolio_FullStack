import { useState } from 'react'
import { Mail, Linkedin, Github, Send, Clock, User, FileText } from 'lucide-react'

const EMAIL = 'tucorreo@ejemplo.com'

function Contact() {
  const [name, setName] = useState('')
  const [subject, setSubject] = useState('')
  const [body, setBody] = useState('')

  const handleSend = (e) => {
    e.preventDefault()
    const mailtoLink = `mailto:${EMAIL}?subject=${encodeURIComponent(subject || 'Contacto desde portfolio')}&body=${encodeURIComponent(`Hola, soy ${name}.\n\n${body}`)}`
    window.location.href = mailtoLink
  }

  return (
    <section className="contact">
      <div className="section-header">
        <h2 className="section-title">Ponte en <span className="highlight">Contacto</span></h2>
        <p className="section-subtitle">
          Tienes un proyecto en mente o simplemente quieres hablar? Escríbeme.
        </p>
      </div>

      <div className="contact__container">
        <div className="contact__info">
          <div className="contact__info-card">
            <div className="contact__info-icon">
              <Mail size={18} strokeWidth={1.8} />
            </div>
            <div className="contact__info-text">
              <h3>Email</h3>
              <a href={`mailto:${EMAIL}`}>{EMAIL}</a>
            </div>
          </div>

          <div className="contact__info-card">
            <div className="contact__info-icon">
              <Linkedin size={18} strokeWidth={1.8} />
            </div>
            <div className="contact__info-text">
              <h3>LinkedIn</h3>
              <a href="https://linkedin.com/in/tu-perfil" target="_blank" rel="noopener noreferrer">
                linkedin.com/in/tu-perfil
              </a>
            </div>
          </div>

          <div className="contact__info-card">
            <div className="contact__info-icon">
              <Github size={18} strokeWidth={1.8} />
            </div>
            <div className="contact__info-text">
              <h3>GitHub</h3>
              <a href="https://github.com/tu-usuario" target="_blank" rel="noopener noreferrer">
                github.com/tu-usuario
              </a>
            </div>
          </div>

          <div className="contact__response">
            <Clock size={14} strokeWidth={2} />
            Respondo en menos de 24 horas
          </div>
        </div>

        <form className="contact__form" onSubmit={handleSend}>
          <div className="form-group">
            <label htmlFor="contact-name">
              <User size={12} />
              Tu nombre
            </label>
            <input
              id="contact-name"
              type="text"
              placeholder="Nombre completo"
              value={name}
              onChange={e => setName(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="contact-subject">
              <FileText size={12} />
              Asunto
            </label>
            <input
              id="contact-subject"
              type="text"
              placeholder="De qué quieres hablar?"
              value={subject}
              onChange={e => setSubject(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label htmlFor="contact-body">
              <Mail size={12} />
              Mensaje
            </label>
            <textarea
              id="contact-body"
              placeholder="Escribe tu mensaje aquí..."
              value={body}
              onChange={e => setBody(e.target.value)}
              rows={5}
              required
            />
          </div>

          <button type="submit" className="btn btn--primary btn--full">
            <Send size={15} />
            Enviar mensaje
          </button>
          <p className="contact__mailto-note">
            <Mail size={11} />
            Se abrirá tu cliente de correo para enviar el mensaje
          </p>
        </form>
      </div>
    </section>
  )
}

export default Contact
