/**
 * server.js — Servidor Express para el portfolio
 *
 * Expone dos grupos de endpoints:
 *   /api/notes  → tablón de notas (legacy, se mantiene por compatibilidad)
 *   /api/forum  → foro tipo Reddit (posts + comentarios)
 *
 * Los datos se almacenan en archivos JSON locales:
 *   notes.json  → notas sueltas
 *   forum.json  → array de posts, cada uno con su array de comments
 */

const express = require('express')
const fs      = require('fs')
const path    = require('path')

const app  = express()
const PORT = 3001

// ── Rutas de datos ─────────────────────────────────────────────────────
const NOTES_FILE = path.join(__dirname, 'notes.json')
const FORUM_FILE = path.join(__dirname, 'forum.json')

/**
 * Clave de administrador.
 * IMPORTANTE: cámbiala antes de publicar el portfolio.
 * Puedes usar una variable de entorno: ADMIN_KEY=mi-clave node server.js
 */
const ADMIN_KEY = process.env.ADMIN_KEY || 'portfolio-admin'

/** Colores disponibles para las notas y avatares de comentarios */
const NOTE_COLORS = [
  '#e8650a', '#d4541a', '#c4830a', '#b05020',
  '#9a7a40', '#8a6030', '#c06040', '#a05030',
]

// Middleware: parsea el body de las peticiones como JSON
app.use(express.json())

// ── Helpers de lectura/escritura ───────────────────────────────────────

/**
 * Lee un archivo JSON y devuelve su contenido.
 * Si el archivo no existe, lo crea con un array vacío.
 * @param {string} filePath - Ruta absoluta al archivo
 * @returns {Array} Contenido del archivo como array
 */
function readJSON(filePath) {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify([]))
    return []
  }
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'))
  } catch {
    return []
  }
}

/**
 * Escribe un array en un archivo JSON con formato legible.
 * @param {string} filePath - Ruta absoluta al archivo
 * @param {Array}  data     - Datos a guardar
 */
function writeJSON(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2))
}

/**
 * Genera una fecha formateada en español.
 * @returns {string} Ejemplo: "17/3/2026"
 */
function today() {
  return new Date().toLocaleDateString('es-ES')
}

/**
 * Elige un color al azar del array de colores disponibles.
 * @returns {string} Código de color hexadecimal
 */
function randomColor() {
  return NOTE_COLORS[Math.floor(Math.random() * NOTE_COLORS.length)]
}

// ══════════════════════════════════════════════════════════════════════
//  NOTAS (legacy — tablón de notas sueltas)
// ══════════════════════════════════════════════════════════════════════

/** GET /api/notes — devuelve todas las notas */
app.get('/api/notes', (req, res) => {
  try {
    res.json(readJSON(NOTES_FILE))
  } catch {
    res.status(500).json({ error: 'Error al leer las notas' })
  }
})

/** POST /api/notes — crea una nueva nota */
app.post('/api/notes', (req, res) => {
  const { author, message } = req.body

  // Validaciones básicas
  if (!author || !message)
    return res.status(400).json({ error: 'El nombre y el mensaje son obligatorios' })
  if (author.trim().length < 2)
    return res.status(400).json({ error: 'El nombre debe tener al menos 2 caracteres' })
  if (message.trim().length < 3)
    return res.status(400).json({ error: 'El mensaje debe tener al menos 3 caracteres' })

  try {
    const notes = readJSON(NOTES_FILE)
    const newNote = {
      id:       Date.now(),
      author:   author.trim().substring(0, 50),
      message:  message.trim().substring(0, 300),
      date:     today(),
      color:    randomColor(),
      rotation: Math.floor(Math.random() * 7) - 3,
    }
    notes.unshift(newNote)   // más reciente primero
    writeJSON(NOTES_FILE, notes)
    res.status(201).json(newNote)
  } catch {
    res.status(500).json({ error: 'Error al guardar la nota' })
  }
})

// ══════════════════════════════════════════════════════════════════════
//  FORO — Posts
// ══════════════════════════════════════════════════════════════════════

/**
 * GET /api/forum
 * Devuelve todos los posts del foro, ordenados por fecha (más reciente primero).
 * Los comentarios están embebidos dentro de cada post.
 */
app.get('/api/forum', (req, res) => {
  try {
    res.json(readJSON(FORUM_FILE))
  } catch {
    res.status(500).json({ error: 'Error al leer el foro' })
  }
})

/**
 * POST /api/forum
 * Crea un nuevo post. Solo puede hacerlo el administrador.
 *
 * Body esperado:
 *   { title: string, content: string, adminKey: string }
 */
app.post('/api/forum', (req, res) => {
  const { title, content, adminKey } = req.body

  // Verificar que quien publica es el admin
  if (adminKey !== ADMIN_KEY)
    return res.status(403).json({ error: 'Contraseña incorrecta' })

  if (!title || !content)
    return res.status(400).json({ error: 'El título y el contenido son obligatorios' })
  if (title.trim().length < 3)
    return res.status(400).json({ error: 'El título debe tener al menos 3 caracteres' })

  try {
    const posts = readJSON(FORUM_FILE)
    const post = {
      id:       Date.now(),
      title:    title.trim().substring(0, 120),
      content:  content.trim().substring(0, 3000),
      author:   'Admin',          // los posts siempre son del admin
      date:     today(),
      pinned:   false,
      comments: [],               // los comentarios empiezan vacíos
    }
    posts.unshift(post)
    writeJSON(FORUM_FILE, posts)
    res.status(201).json(post)
  } catch {
    res.status(500).json({ error: 'Error al crear el post' })
  }
})

/**
 * DELETE /api/forum/:id
 * Elimina un post y todos sus comentarios. Solo el admin puede hacerlo.
 *
 * Body esperado:
 *   { adminKey: string }
 */
app.delete('/api/forum/:id', (req, res) => {
  const { adminKey } = req.body

  if (adminKey !== ADMIN_KEY)
    return res.status(403).json({ error: 'Contraseña incorrecta' })

  try {
    const posts   = readJSON(FORUM_FILE)
    const filtered = posts.filter(p => p.id !== parseInt(req.params.id))
    writeJSON(FORUM_FILE, filtered)
    res.json({ ok: true })
  } catch {
    res.status(500).json({ error: 'Error al eliminar el post' })
  }
})

// ══════════════════════════════════════════════════════════════════════
//  FORO — Comentarios
// ══════════════════════════════════════════════════════════════════════

/**
 * POST /api/forum/:id/comment
 * Añade un comentario a un post existente.
 * Cualquier visitante puede comentar (sin autenticación).
 *
 * Body esperado:
 *   { author: string, content: string }
 */
app.post('/api/forum/:id/comment', (req, res) => {
  const { author, content } = req.body

  if (!author || !content)
    return res.status(400).json({ error: 'El nombre y el comentario son obligatorios' })
  if (author.trim().length < 2)
    return res.status(400).json({ error: 'El nombre debe tener al menos 2 caracteres' })
  if (content.trim().length < 2)
    return res.status(400).json({ error: 'El comentario debe tener al menos 2 caracteres' })

  try {
    const posts = readJSON(FORUM_FILE)
    // Busca el post por id (parseamos porque req.params.id es string)
    const post = posts.find(p => p.id === parseInt(req.params.id))

    if (!post)
      return res.status(404).json({ error: 'Post no encontrado' })

    const comment = {
      id:      Date.now(),
      author:  author.trim().substring(0, 50),
      content: content.trim().substring(0, 600),
      date:    today(),
      color:   randomColor(),
    }

    // Aseguramos que el array de comments existe antes de hacer push
    if (!Array.isArray(post.comments)) post.comments = []
    post.comments.push(comment)

    writeJSON(FORUM_FILE, posts)
    res.status(201).json(comment)
  } catch {
    res.status(500).json({ error: 'Error al guardar el comentario' })
  }
})

/**
 * DELETE /api/forum/:postId/comment/:commentId
 * Elimina un comentario de un post. Solo el admin puede hacerlo.
 *
 * Body esperado:
 *   { adminKey: string }
 */
app.delete('/api/forum/:postId/comment/:commentId', (req, res) => {
  const { adminKey } = req.body

  if (adminKey !== ADMIN_KEY)
    return res.status(403).json({ error: 'Contraseña incorrecta' })

  try {
    const posts = readJSON(FORUM_FILE)
    const post  = posts.find(p => p.id === parseInt(req.params.postId))

    if (!post)
      return res.status(404).json({ error: 'Post no encontrado' })

    post.comments = (post.comments || []).filter(
      c => c.id !== parseInt(req.params.commentId)
    )

    writeJSON(FORUM_FILE, posts)
    res.json({ ok: true })
  } catch {
    res.status(500).json({ error: 'Error al eliminar el comentario' })
  }
})

// ── Arrancar el servidor ──────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`Servidor de foro corriendo en http://localhost:${PORT}`)
  console.log(`Admin key: ${ADMIN_KEY === 'portfolio-admin' ? '⚠️  usando clave por defecto (cámbiala)' : '✓ configurada'}`)
})
